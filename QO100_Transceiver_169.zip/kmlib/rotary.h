void init_rotencoder();
void close_gpio();
int getEncSteps(int idx);
